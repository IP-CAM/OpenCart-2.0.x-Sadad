<?php
// Heading
$_['heading_title']         = ' SADAD Online Payment';

// Text
$_['text_edit']          = 'Edit Sadad';
$_['text_payment']          = 'Payment';
$_['text_sadad']			= '<img src="view/image/payment/sadad.png" alt="Paymate" title="" style="border: 1px solid #EEEEEE;" />';


$_['text_success']          = 'Success: You have modified Sadad Payment module!';
$_['text_live']             = 'Payment Environment';
$_['text_beta']             = 'Beta';





?>
